-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 13-Fev-2022 às 22:56
-- Versão do servidor: 10.4.21-MariaDB
-- versão do PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `teste`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cami`
--

CREATE TABLE `tb_cami` (
  `cami_id` int(11) NOT NULL,
  `cami_placa` varchar(7) NOT NULL,
  `cami_desc` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_cami`
--

INSERT INTO `tb_cami` (`cami_id`, `cami_placa`, `cami_desc`) VALUES
(1, 'my scan', 'truck'),
(2, 'SD300', 'scania');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_carro`
--

CREATE TABLE `tb_carro` (
  `carro_id` int(11) NOT NULL,
  `carro_placa` varchar(7) NOT NULL,
  `carro_desc` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_carro`
--

INSERT INTO `tb_carro` (`carro_id`, `carro_placa`, `carro_desc`) VALUES
(1, 'meu car', 'onix'),
(2, 'KH2', 'Hb20 '),
(3, '150ka', 'factor ybrdd'),
(4, 'MK30', 'toyoto civic');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_moto`
--

CREATE TABLE `tb_moto` (
  `moto_id` int(11) NOT NULL,
  `moto_placa` varchar(7) NOT NULL,
  `moto_desc` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_moto`
--

INSERT INTO `tb_moto` (`moto_id`, `moto_placa`, `moto_desc`) VALUES
(2, 'nels', 'factor ybr'),
(3, 'Mk250', 'fazer 250 vermelha e preta'),
(4, '12', 'fazer 250 vermelha e preta');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_motorista`
--

CREATE TABLE `tb_motorista` (
  `mot_id` int(4) NOT NULL,
  `mot_nome` varchar(50) NOT NULL,
  `mot_cpf` varchar(11) NOT NULL,
  `mot_placa` varchar(7) NOT NULL,
  `mot_descricao` varchar(30) NOT NULL,
  `mot_modelo` int(1) NOT NULL,
  `mot_habilitacao` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_motorista`
--

INSERT INTO `tb_motorista` (`mot_id`, `mot_nome`, `mot_cpf`, `mot_placa`, `mot_descricao`, `mot_modelo`, `mot_habilitacao`) VALUES
(31, 'lorna2333333', '', 'factor ', 'nels', 1, 'a'),
(37, 'nelson22', '70093359233', 'fazer 2', 'Mk250', 1, 'a'),
(38, '140gg', '4444', 'Hb20 ', 'meu car', 2, 'ab'),
(45, 'lorn', '544', 'onix', 'meu car', 2, 'ab'),
(46, 'lorn', '544', 'onix', 'meu car', 2, 'ab'),
(47, 'antonio', '848484', 'factor ', 'nels', 1, 'a'),
(48, 'antonio', '848484', 'factor ', 'nels', 1, 'a'),
(49, 'pivane', '7884545554', 'toyoto ', 'MK30', 2, 'ab'),
(51, 'teste', '2322', 'MK30', 'toyoto civic', 2, 'ab'),
(52, 'teste', '2322', 'MK30', 'toyoto civic', 2, 'ab');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_uso_veiculo`
--

CREATE TABLE `tb_uso_veiculo` (
  `uve_id` int(10) NOT NULL,
  `mot_nome` varchar(50) NOT NULL,
  `mot_placa` varchar(7) NOT NULL,
  `mot_descricao` varchar(40) NOT NULL,
  `use_data` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_uso_veiculo`
--

INSERT INTO `tb_uso_veiculo` (`uve_id`, `mot_nome`, `mot_placa`, `mot_descricao`, `use_data`) VALUES
(38, 'lorn', 'onix', 'meu car', '2022-02-13 18:30:31'),
(39, 'antonio', 'factor ', 'nels', '2022-02-13 18:31:26'),
(40, 'pivane', 'toyoto ', 'MK30', '2022-02-13 18:47:40'),
(41, 'teste', 'MK30', 'toyoto civic', '2022-02-13 18:51:29');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_veiculo`
--

CREATE TABLE `tb_veiculo` (
  `vei_id` int(4) NOT NULL,
  `vei_placa` varchar(7) NOT NULL,
  `vei_descricao` varchar(30) NOT NULL,
  `vei_modelo` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_veiculo`
--

INSERT INTO `tb_veiculo` (`vei_id`, `vei_placa`, `vei_descricao`, `vei_modelo`) VALUES
(25, 'Mk250', 'fazer 250 vermelha e preta', 2),
(26, 'KH2', 'Hb20 ', 2),
(29, '150ka', 'factor ybrdd', 2),
(30, 'MK30', 'toyoto civic', 2);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `tb_cami`
--
ALTER TABLE `tb_cami`
  ADD PRIMARY KEY (`cami_id`);

--
-- Índices para tabela `tb_carro`
--
ALTER TABLE `tb_carro`
  ADD PRIMARY KEY (`carro_id`);

--
-- Índices para tabela `tb_moto`
--
ALTER TABLE `tb_moto`
  ADD PRIMARY KEY (`moto_id`);

--
-- Índices para tabela `tb_motorista`
--
ALTER TABLE `tb_motorista`
  ADD PRIMARY KEY (`mot_id`);

--
-- Índices para tabela `tb_uso_veiculo`
--
ALTER TABLE `tb_uso_veiculo`
  ADD PRIMARY KEY (`uve_id`);

--
-- Índices para tabela `tb_veiculo`
--
ALTER TABLE `tb_veiculo`
  ADD PRIMARY KEY (`vei_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_cami`
--
ALTER TABLE `tb_cami`
  MODIFY `cami_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_carro`
--
ALTER TABLE `tb_carro`
  MODIFY `carro_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_moto`
--
ALTER TABLE `tb_moto`
  MODIFY `moto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_motorista`
--
ALTER TABLE `tb_motorista`
  MODIFY `mot_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT de tabela `tb_uso_veiculo`
--
ALTER TABLE `tb_uso_veiculo`
  MODIFY `uve_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de tabela `tb_veiculo`
--
ALTER TABLE `tb_veiculo`
  MODIFY `vei_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
