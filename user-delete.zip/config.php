<?php

$dbname='teste';

$hostname='localhost';

$password="";

$username='root';

$pdo= new PDO("mysql:dbname=$dbname;host=$hostname", $username, $password);


?>